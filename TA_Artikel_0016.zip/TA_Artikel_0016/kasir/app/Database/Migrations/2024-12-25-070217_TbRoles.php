<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class TbRoles extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id_role' => [
                'type'           => 'INT',
                'constraint'     => 11,
            ],
            'keterangan' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
        ]);
        $this->forge->addKey('id_role', TRUE);
        $this->forge->createTable('tb_roles');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_roles');
    }
}
