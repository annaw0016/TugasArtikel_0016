<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class User extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id_user' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'unique'     =>  true,
            ],
            'username' => [
                'type'       => 'VARCHAR',
                'constraint' => '30',
                'unique'     =>  true,
            ],
            'password' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'nama' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'alamat' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'id_role' => [
                'type'           => 'INT',
                'constraint'     => 11,
            ],
            'avatar' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'status' => [
                'type'           => 'INT',
                'constraint'     => 1,
            ],
            'token' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'ip_address' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
            ],
            'created_at datetime default now()',
            'updated_at datetime default now()',
            'deleted_at datetime default now()'
        ]);
        $this->forge->addKey('id_user', TRUE);
        $this->forge->createTable('tb_user');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_user');
    }
}