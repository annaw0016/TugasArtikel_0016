<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class TbPenjualan extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id_jual' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
            ],
            'invoice' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
            'id_pelanggan' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
            ],
            'total_harga' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'     =>  true,
            ],
            'diskon' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'     =>  true,
            ],
            'total_akhir' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'     =>  true,
            ],
            'tunai' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'     =>  true,
            ],
            'kembalian' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'     =>  true,
            ],
            'catatan' => [
                'type' => 'TEXT',
            ],
            'tanggal' => [
                'type' => 'DATE',
            ],
            'id_user' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'     =>  true,
            ],
            'ip_address' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
            ],
            'created_at datetime default now()',
            'updated_at datetime default now()',
            'deleted_at datetime default now()'
        ]);
        $this->forge->addKey('id_jual', TRUE);
        $this->forge->createTable('tb_penjualan');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_penjualan');
    }
}