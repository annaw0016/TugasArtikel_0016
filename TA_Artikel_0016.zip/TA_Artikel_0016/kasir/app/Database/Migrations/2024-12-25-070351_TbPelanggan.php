<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class TbPelanggan extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id_pelanggan' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
            ],
            'nama_pelanggan' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
            ],
            'jenkel' => [
                'type'           => 'VARCHAR',
                'constraint'     => '1',
            ],
            'telp_pelanggan' => [
                'type'           => 'VARCHAR',
                'constraint'     => '20',
            ],
            'alamat_pelanggan' => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',
            ],
            'created_at datetime default now()',
            'updated_at datetime default now()',
            'deleted_at datetime default now()'
        ]);
        $this->forge->addKey('id_pelanggan', TRUE);
        $this->forge->createTable('tb_pelanggan');
    }

    public function down()
    {
        //
        $this->forge->dropTable('tb_pelanggan');
    }
}